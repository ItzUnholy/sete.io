"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Player {
  id: string
  name: string
  x: number
  y: number
  trail: { x: number; y: number }[]
  territory: { x: number; y: number }[]
  color: string
  score: number
}

interface GameState {
  players: Player[]
  gridSize: number
  canvasWidth: number
  canvasHeight: number
}

export default function SplixGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<GameState>({
    players: [],
    gridSize: 20,
    canvasWidth: 800,
    canvasHeight: 600,
  })
  const [playerName, setPlayerName] = useState("")
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentPlayer, setCurrentPlayer] = useState<Player | null>(null)
  const keysPressed = useRef<Set<string>>(new Set())

  // Inicializar jogador
  const startGame = () => {
    if (!playerName.trim()) return

    const newPlayer: Player = {
      id: Math.random().toString(36).substr(2, 9),
      name: playerName,
      x: Math.floor(Math.random() * (gameState.canvasWidth / gameState.gridSize)) * gameState.gridSize,
      y: Math.floor(Math.random() * (gameState.canvasHeight / gameState.gridSize)) * gameState.gridSize,
      trail: [],
      territory: [],
      color: `hsl(${Math.random() * 360}, 70%, 50%)`,
      score: 0,
    }

    // Criar território inicial (pequeno quadrado)
    for (let i = -1; i <= 1; i++) {
      for (let j = -1; j <= 1; j++) {
        newPlayer.territory.push({
          x: newPlayer.x + i * gameState.gridSize,
          y: newPlayer.y + j * gameState.gridSize,
        })
      }
    }

    setCurrentPlayer(newPlayer)
    setGameState((prev) => ({
      ...prev,
      players: [newPlayer],
    }))
    setIsPlaying(true)
  }

  // Controles do teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current.add(e.key.toLowerCase())
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current.delete(e.key.toLowerCase())
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [])

  // Game loop
  useEffect(() => {
    if (!isPlaying || !currentPlayer) return

    const gameLoop = setInterval(() => {
      setCurrentPlayer((prev) => {
        if (!prev) return prev

        let newX = prev.x
        let newY = prev.y
        const speed = gameState.gridSize

        // Movimento baseado nas teclas pressionadas
        if (keysPressed.current.has("arrowup") || keysPressed.current.has("w")) {
          newY = Math.max(0, prev.y - speed)
        }
        if (keysPressed.current.has("arrowdown") || keysPressed.current.has("s")) {
          newY = Math.min(gameState.canvasHeight - gameState.gridSize, prev.y + speed)
        }
        if (keysPressed.current.has("arrowleft") || keysPressed.current.has("a")) {
          newX = Math.max(0, prev.x - speed)
        }
        if (keysPressed.current.has("arrowright") || keysPressed.current.has("d")) {
          newX = Math.min(gameState.canvasWidth - gameState.gridSize, prev.x + speed)
        }

        // Se não se moveu, não atualizar
        if (newX === prev.x && newY === prev.y) return prev

        const newTrail = [...prev.trail]
        const isInOwnTerritory = prev.territory.some((t) => t.x === prev.x && t.y === prev.y)

        // Se estava no próprio território e saiu, começar novo trail
        if (isInOwnTerritory && !prev.territory.some((t) => t.x === newX && t.y === newY)) {
          newTrail.push({ x: prev.x, y: prev.y })
        }
        // Se está fora do território, continuar trail
        else if (!prev.territory.some((t) => t.x === newX && t.y === newY) && newTrail.length > 0) {
          newTrail.push({ x: prev.x, y: prev.y })
        }
        // Se voltou ao próprio território, capturar área
        else if (prev.territory.some((t) => t.x === newX && t.y === newY) && newTrail.length > 0) {
          // Simples captura de área - adicionar trail ao território
          const newTerritory = [...prev.territory, ...newTrail, { x: prev.x, y: prev.y }]
          return {
            ...prev,
            x: newX,
            y: newY,
            trail: [],
            territory: newTerritory,
            score: newTerritory.length,
          }
        }

        return {
          ...prev,
          x: newX,
          y: newY,
          trail: newTrail,
        }
      })
    }, 150)

    return () => clearInterval(gameLoop)
  }, [isPlaying, currentPlayer, gameState.gridSize, gameState.canvasWidth, gameState.canvasHeight])

  // Renderização
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !currentPlayer) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Limpar canvas
    ctx.fillStyle = "#2a2a2a"
    ctx.fillRect(0, 0, gameState.canvasWidth, gameState.canvasHeight)

    // Desenhar grid
    ctx.strokeStyle = "#404040"
    ctx.lineWidth = 1
    for (let x = 0; x <= gameState.canvasWidth; x += gameState.gridSize) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, gameState.canvasHeight)
      ctx.stroke()
    }
    for (let y = 0; y <= gameState.canvasHeight; y += gameState.gridSize) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(gameState.canvasWidth, y)
      ctx.stroke()
    }

    // Desenhar território
    ctx.fillStyle = currentPlayer.color + "80" // Semi-transparente
    currentPlayer.territory.forEach((cell) => {
      ctx.fillRect(cell.x, cell.y, gameState.gridSize, gameState.gridSize)
    })

    // Desenhar trail
    ctx.fillStyle = currentPlayer.color
    currentPlayer.trail.forEach((cell) => {
      ctx.fillRect(cell.x, cell.y, gameState.gridSize, gameState.gridSize)
    })

    // Desenhar jogador
    ctx.fillStyle = currentPlayer.color
    ctx.fillRect(currentPlayer.x, currentPlayer.y, gameState.gridSize, gameState.gridSize)

    // Adicionar borda ao jogador
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 2
    ctx.strokeRect(currentPlayer.x, currentPlayer.y, gameState.gridSize, gameState.gridSize)
  }, [currentPlayer, gameState])

  if (!isPlaying) {
    return (
      <div className="min-h-screen bg-gray-800 flex items-center justify-center p-4">
        <div className="flex gap-8 items-start">
          <Card className="w-80 bg-green-600 border-green-500">
            <CardHeader>
              <CardTitle className="text-white text-center">Splix.io Clone</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Enter your name"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="bg-white"
                onKeyDown={(e) => e.key === "Enter" && startGame()}
              />
              <Button
                onClick={startGame}
                className="w-full bg-green-500 hover:bg-green-400"
                disabled={!playerName.trim()}
              >
                Join
              </Button>
            </CardContent>
          </Card>

          <Card className="w-80 bg-green-600 border-green-500">
            <CardHeader>
              <CardTitle className="text-white">Como Jogar</CardTitle>
            </CardHeader>
            <CardContent className="text-white text-sm space-y-2">
              <p>• Use WASD ou setas para mover</p>
              <p>• Saia do seu território para criar um trail</p>
              <p>• Volte ao seu território para capturar área</p>
              <p>• Quanto maior sua área, maior sua pontuação</p>
              <p>• Cuidado para não colidir com outros jogadores!</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="flex gap-4 justify-center">
        <div className="flex flex-col items-center">
          <div className="mb-4 flex gap-4 text-white">
            <span>Jogador: {currentPlayer?.name}</span>
            <span>Pontuação: {currentPlayer?.score || 0}</span>
          </div>
          <canvas
            ref={canvasRef}
            width={gameState.canvasWidth}
            height={gameState.canvasHeight}
            className="border-2 border-gray-600 bg-gray-800"
          />
          <div className="mt-4 text-white text-sm text-center">Use WASD ou setas para mover</div>
        </div>
      </div>
    </div>
  )
}
